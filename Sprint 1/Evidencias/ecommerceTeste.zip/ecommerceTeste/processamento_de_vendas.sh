#!/usr/bin/env bash

#variáveis de data/nome
dataHoje=$(date +%Y%m%d)
dataRelatorio=$(date +%Y/%m/%d\ %H:%M)
nomebackupTeste=dados-$dataHoje
nomeRelatorio=relatorio-$dataHoje

#variáveis de caminhos
caminhoRelatorio=/home/arthur/Documents/ecommerceTeste/vendasTeste/backupTeste/$nomeRelatorio.txt
caminhoDadosVendas=/home/arthur/Documents/ecommerceTeste/dados_de_vendas.csv
caminhobackupTeste=/home/arthur/Documents/ecommerceTeste/vendasTeste/backupTeste
caminhoPastavendasTeste=/home/arthur/Documents/ecommerceTeste/vendasTeste

if [ ! -d "/home/arthur/ecommerceTeste/vendasTeste" ];then
	#criação de diretórios/subdiretórios e renomeação dos arquivos
	mkdir $caminhoPastavendasTeste
	cp $caminhoDadosVendas $caminhoPastavendasTeste
	cd $caminhoPastavendasTeste
	mkdir backupTeste
	cp dados_de_vendas.csv $nomebackupTeste.csv
	mv $nomebackupTeste.csv backupTeste
	cd backupTeste
	mv $nomebackupTeste.csv backupTeste-$nomebackupTeste.csv
	touch $nomeRelatorio.txt

	#relatório
	echo "Data do sistema operacional:" >> $caminhoRelatorio
	echo $dataRelatorio >> $caminhoRelatorio

	echo "Data do primeiro registro de venda: " >> $caminhoRelatorio
	awk -F "," 'NR==2 {print $5}' $caminhoDadosVendas >> $caminhoRelatorio

	echo "Data do último registro de venda: " >> $caminhoRelatorio
	awk -F "," 'END {print $5}' $caminhoDadosVendas  >> $caminhoRelatorio 

	echo "Quantidade total de itens diferentes vendidos:" >> $caminhoRelatorio
	quantidade=$(sort $caminhoDadosVendas |uniq|wc -l)
	echo $((quantidade - 1)) >> $caminhoRelatorio

	echo "10 primeiras linhas do arquivo backup-dados" >> $caminhoRelatorio
	awk -F "," 'NR>=2 && NR<=11 {print $5}' $caminhobackupTeste/backupTeste-$nomebackupTeste.csv  >> $caminhoRelatorio

	#compactação/exclusão de arquivos
	zip -r backupTeste-$nomebackupTeste.zip backupTeste-$nomebackupTeste.csv
	rm $caminhobackupTeste/backupTeste-$nomebackupTeste.csv
	rm $caminhoPastavendasTeste/dados_de_vendas.csv
 else
	#movimentando/renomeando arquivos
	cp $caminhoDadosVendas $caminhoPastavendasTeste
	cd $caminhoPastavendasTeste
	cp dados_de_vendas.csv $nomebackupTeste.csv
	mv $nomebackupTeste.csv backupTeste
	cd backupTeste
	mv $nomebackupTeste.csv backupTeste-$nomebackupTeste.csv
	touch $nomeRelatorio.txt

	#relatório
	echo "Data do sistema operacional:" >> $caminhoRelatorio
	echo $dataRelatorio >> $caminhoRelatorio

	echo "Data do primeiro registro de venda: " >> $caminhoRelatorio
	awk -F "," 'NR==2 {print $5}' $caminhoDadosVendas >> $caminhoRelatorio

	echo "Data do último registro de venda: " >> $caminhoRelatorio
	awk -F "," 'END {print $5}' $caminhoDadosVendas  >> $caminhoRelatorio 

	echo "Quantidade total de itens diferentes vendidos:" >> $caminhoRelatorio
	quantidade=$(cut -d"," -f2 $caminhoDadosVendas|sort|uniq|wc -l)
	echo $((quantidade - 1)) >> $caminhoRelatorio

	echo "10 primeiras linhas do arquivo backupTeste-dados" >> $caminhoRelatorio
	awk -F "," 'NR>=2 && NR<=11 {print $5}' $caminhobackupTeste/backupTeste-$nomebackupTeste.csv  >> $caminhoRelatorio

	#compactação/exclusão de arquivos
	zip -r backupTeste-$nomebackupTeste.zip backupTeste-$nomebackupTeste.csv
	rm $caminhobackupTeste/backupTeste-$nomebackupTeste.csv
	rm $caminhoPastavendasTeste/dados_de_vendas.csv
 fi
